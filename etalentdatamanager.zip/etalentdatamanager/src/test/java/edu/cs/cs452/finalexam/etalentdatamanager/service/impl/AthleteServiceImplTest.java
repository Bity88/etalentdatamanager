package edu.cs.cs452.finalexam.etalentdatamanager.service.impl;

import edu.cs.cs452.finalexam.etalentdatamanager.model.Athlete;
import edu.cs.cs452.finalexam.etalentdatamanager.service.AthleteService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

import static org.junit.jupiter.api.Assertions.*;

class AthleteServiceImplTest {

    @Autowired
    private AthleteService athleteService;

    @Test
    void noOfEliteAthletes() {


       int actual = athleteService.noOfEliteAthletes();
        int expected = 1;
        assertEquals(actual, expected);

    }
}