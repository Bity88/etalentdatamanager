package edu.cs.cs452.finalexam.etalentdatamanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtalentdatamanagerApplicationTests {

    @Test
    void contextLoads() {
    }

}
