package edu.cs.cs452.finalexam.etalentdatamanager.service;

import edu.cs.cs452.finalexam.etalentdatamanager.model.Athlete;

import javax.persistence.criteria.CriteriaBuilder;
import java.util.List;

public interface AthleteService {

    void addAthlete(Athlete athlete);
    List<Athlete> getAllAthlete();

    List<Athlete> eliteAthletes();

    Integer noOfEliteAthletes();
}
