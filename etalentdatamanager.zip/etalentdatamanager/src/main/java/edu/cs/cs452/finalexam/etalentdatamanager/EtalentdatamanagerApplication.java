package edu.cs.cs452.finalexam.etalentdatamanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EtalentdatamanagerApplication {

    public static void main(String[] args) {
        SpringApplication.run(EtalentdatamanagerApplication.class, args);
    }

}
