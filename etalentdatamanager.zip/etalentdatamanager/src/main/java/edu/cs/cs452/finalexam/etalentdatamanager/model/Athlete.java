package edu.cs.cs452.finalexam.etalentdatamanager.model;


import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.time.LocalDate;

@Entity
@Data
@NoArgsConstructor
public class Athlete {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long athleteId;

    @NotEmpty
    @Column(name = "SSN")
    private String ssn;


    @NotEmpty
    @Column(name = "fullName")
    private String fullName;


    private String phoneNumber;

    @NotNull
    @Column(name = "dateOfBirth")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private LocalDate dateOfBirth;

    @NotNull
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    @Column(name = "dateOfReg")
    private LocalDate dateOfRegistration;

    @NotNull
    @Column(name = "MedalsWon")
    private int totalNumberOfMedalsWon;

    @NotNull
    @Column(name = "salary")
    private double monthSalary;


    @Column(name = "email")
    private String emailAddress;

}
