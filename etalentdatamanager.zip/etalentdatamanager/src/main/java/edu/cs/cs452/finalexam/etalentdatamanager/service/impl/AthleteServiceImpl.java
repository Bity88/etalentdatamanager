package edu.cs.cs452.finalexam.etalentdatamanager.service.impl;

import edu.cs.cs452.finalexam.etalentdatamanager.model.Athlete;
import edu.cs.cs452.finalexam.etalentdatamanager.repository.AthleteRepository;
import edu.cs.cs452.finalexam.etalentdatamanager.service.AthleteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.web.servlet.theme.AbstractThemeResolver;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;




@Service
public class AthleteServiceImpl implements AthleteService {

    @Autowired
    private AthleteRepository athleteRepository;

    @Override
    public void addAthlete(Athlete athlete) {

        athleteRepository.save(athlete);

    }

    @Override
    public List<Athlete> getAllAthlete() {
        return athleteRepository.findAll(Sort.by("fullName"));
    }

    @Override
    public List<Athlete> eliteAthletes() {

        LocalDate actualDate = LocalDate.now().minusYears(5);
        List<Athlete> eliteAthlete = new ArrayList<>();

        List<Athlete> athleteList = athleteRepository.findAll(Sort.by("monthSalary").descending());
        for(Athlete a: athleteList){
            if(a.getDateOfRegistration().isBefore(actualDate) && a.getTotalNumberOfMedalsWon()>= 3)
                a.setMonthSalary(0.15 * a.getMonthSalary());
                eliteAthlete.add(a);

        }
        return eliteAthlete;
    }

    @Override
    public Integer noOfEliteAthletes() {
        List<Athlete> athleteList = new ArrayList<>();
        Athlete a1 = new Athlete();

        a1.setMonthSalary(25000);
        a1.setDateOfBirth(LocalDate.of(2011,01,02));
        a1.setDateOfRegistration(LocalDate.of(2011,01,02));
        a1.setEmailAddress("a1@gmail.com");

        athleteList.add(a1);

        return athleteList.size();
    }
}
